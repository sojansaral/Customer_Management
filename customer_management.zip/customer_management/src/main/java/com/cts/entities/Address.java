package com.cts.entities;


import com.fasterxml.jackson.annotation.JsonInclude;

import jakarta.persistence.Embeddable;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonInclude(JsonInclude.Include.NON_NULL)
@AllArgsConstructor
@NoArgsConstructor
@Data
@Embeddable
public class Address {
	@NotNull(message="houseNo should not be null")
	private String houseNo;
	
	@NotNull(message="Street should not be null")
	private String street;
	
	@NotNull(message="Landmark should not be null")
	private String landmark;
	
	@NotNull(message="City should not be null")
	private String city;
	
	@NotNull(message="State should not be null")
	private String state;
	
	@NotNull(message="Pin should not be null")
	private String pin;
}
