package com.cts.entities;


import jakarta.persistence.AttributeOverride;
import jakarta.persistence.AttributeOverrides;
import jakarta.persistence.Column;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name="customers")
public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@NotNull(message="FirstName should not be null")
	@Pattern(regexp = "[a-zA-Z]+", message = "First name should contain only letters")
	@Column(nullable = false)
	private String firstName;
	
    @Pattern(regexp = "[a-zA-Z]+", message = "Last name should contain only letters")
	@NotNull(message="LastName should not be null")
	private String lastName;
    
    @Pattern(regexp = "[a-zA-Z]+", message = "Nick name should contain only letters")
	private String nickName;
    
	@NotNull(message="Gender should not be null")
	@Pattern(regexp = "[MmFf]", message="Gender should be either M or F")
	@Size(min = 1, max = 1, message="Gender should be a single character")
	private String gender;
	
	@NotNull(message="Age should not be null")
	@Max(60)
	@Min(18)
	private int age;
	
	@NotNull(message="Qualification should not be null")
    @Pattern(regexp = "[a-zA-Z\s']+[0-9]*")
	private String qualification;
	
	@Embedded
	@AttributeOverrides({
		@AttributeOverride(name="houseNo",column=@Column(name="permanent_houseNo")),
		@AttributeOverride(name="street",column=@Column(name="permanent_street")),
		@AttributeOverride(name="landmark",column=@Column(name="permanent_landmark")),
		@AttributeOverride(name="city",column=@Column(name="permanent_city")),
		@AttributeOverride(name="state",column=@Column(name="permanent_state")),
		@AttributeOverride(name="pin",column=@Column(name="permanent_pin"))
	})
	@Valid
	private Address permanent_address;
	
	@Embedded
	@AttributeOverrides({
		@AttributeOverride(name="houseNo",column=@Column(name="communication_houseNo")),
		@AttributeOverride(name="street",column=@Column(name="communication_street")),
		@AttributeOverride(name="landmark",column=@Column(name="communication_landmark")),
		@AttributeOverride(name="city",column=@Column(name="communication_city")),
		@AttributeOverride(name="state",column=@Column(name="communication_state")),
		@AttributeOverride(name="pin",column=@Column(name="communication_pin"))
	})
	@Valid
	private Address communication_address;
	
	@NotNull(message="Notes should not be null")
	private String notes;
	
}
