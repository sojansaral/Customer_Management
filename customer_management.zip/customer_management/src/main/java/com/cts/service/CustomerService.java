package com.cts.service;

import java.util.List;

import com.cts.dto.CustomerUpdate;
import com.cts.entities.Customer;

// Service interface for customer management operations 
public interface CustomerService {
    
    // Retrieves all customers 
    List<Customer> getAll();

    // Retrieves a customer by ID 
    Customer getById(int id);

    // Adds a new customer 
    Customer addCustomer(Customer customer);

    // Updates a customer's complete details 
    Customer updateCustomer(int id, Customer customer);

    // Partially updates a customer's details 
    Customer updatePartialCustomer(int id, CustomerUpdate customer);

    // Deletes a customer by ID 
    void deleteCustomer(int id);
}
