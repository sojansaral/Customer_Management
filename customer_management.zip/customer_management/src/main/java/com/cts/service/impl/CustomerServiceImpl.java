package com.cts.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.cts.dto.CustomerUpdate;
import com.cts.entities.Customer;
import com.cts.exceptions.CustomerNotFoundException;
import com.cts.exceptions.CustomerServiceException;
import com.cts.repository.CustomerRepository;
import com.cts.service.CustomerService;

// Implementation of CustomerService handling customer operations 
@Service
public class CustomerServiceImpl implements CustomerService {

    private CustomerRepository customerRepository;

    // Constructor to inject CustomerRepository dependency 
    @Autowired
    public CustomerServiceImpl(CustomerRepository customerRepository) {
        super();
        this.customerRepository = customerRepository;
    }

    // Retrieves all customers 
    @Override
    public List<Customer> getAll() {
        return customerRepository.findAll();
    }

    // Retrieves a customer by ID 
    @Override
    public Customer getById(int id) {
        return customerRepository.findById(id)
                .orElseThrow(() -> new CustomerNotFoundException("Customer with Id " + id + " is not found"));
    }

    // Adds a new customer 
    @Override
    public Customer addCustomer(Customer customer) {
        return customerRepository.save(customer);
    }

    // Updates specific customer fields (partial update) 
    @Override
    public Customer updatePartialCustomer(int id, CustomerUpdate customer) {
    	CustomerUpdate customerUpdate=new CustomerUpdate();
    	if(customerUpdate.equals(customer)) {
    		throw new CustomerNotFoundException("Please enter values to update");
    	}
        if (!customerRepository.existsById(id)) {
            throw new CustomerNotFoundException("Customer with Id " + id + " is not found");
        }
        Customer cust = customerRepository.findById(id).get();
        
        // Update non-null fields
        if (customer.getAge() != null) cust.setAge(customer.getAge());
        if (customer.getFirstName() != null) cust.setFirstName(customer.getFirstName());
        if (customer.getLastName() != null) cust.setLastName(customer.getLastName());
        if (customer.getGender() != null) cust.setGender(customer.getGender());
        if (customer.getNickName() != null) cust.setNickName(customer.getNickName());
        if (customer.getQualification() != null) cust.setQualification(customer.getQualification());
        if (customer.getNotes() != null) cust.setNotes(customer.getNotes());

        // Update addresses if present
        if (customer.getPermanent_address() != null) {
            if (customer.getPermanent_address().getHouseNo() != null) cust.getPermanent_address().setHouseNo(customer.getPermanent_address().getHouseNo());
            if (customer.getPermanent_address().getStreet() != null) cust.getPermanent_address().setStreet(customer.getPermanent_address().getStreet());
            if (customer.getPermanent_address().getLandmark() != null) cust.getPermanent_address().setLandmark(customer.getPermanent_address().getLandmark());
            if (customer.getPermanent_address().getCity() != null) cust.getPermanent_address().setCity(customer.getPermanent_address().getCity());
            if (customer.getPermanent_address().getState() != null) cust.getPermanent_address().setState(customer.getPermanent_address().getState());
            if (customer.getPermanent_address().getPin() != null) cust.getPermanent_address().setPin(customer.getPermanent_address().getPin());
        }

        if (customer.getCommunication_address() != null) {
            if (customer.getCommunication_address().getHouseNo() != null) cust.getCommunication_address().setHouseNo(customer.getCommunication_address().getHouseNo());
            if (customer.getCommunication_address().getStreet() != null) cust.getCommunication_address().setStreet(customer.getCommunication_address().getStreet());
            if (customer.getCommunication_address().getLandmark() != null) cust.getCommunication_address().setLandmark(customer.getCommunication_address().getLandmark());
            if (customer.getCommunication_address().getCity() != null) cust.getCommunication_address().setCity(customer.getCommunication_address().getCity());
            if (customer.getCommunication_address().getState() != null) cust.getCommunication_address().setState(customer.getCommunication_address().getState());
            if (customer.getCommunication_address().getPin() != null) cust.getCommunication_address().setPin(customer.getCommunication_address().getPin());
        }

        return customerRepository.save(cust);
    }

    // Deletes a customer by ID 
    @Override
    public void deleteCustomer(int id) {
        customerRepository.deleteById(id);
    }

    // Updates a customer's complete details 
    @Override
    public Customer updateCustomer(int id, Customer customer) {
        if (!customerRepository.existsById(id)) {
            throw new CustomerNotFoundException("Customer with Id " + id + " is not found");
        }
        Customer cust = customerRepository.findById(id).get();

        // Full update of customer fields
        cust.setFirstName(customer.getFirstName());
        cust.setLastName(customer.getLastName());
        cust.setNickName(customer.getNickName());
        cust.setGender(customer.getGender());
        cust.setAge(customer.getAge());
        cust.setPermanent_address(customer.getPermanent_address());
        cust.setCommunication_address(customer.getCommunication_address());
        cust.setQualification(customer.getQualification());
        cust.setNotes(customer.getNotes());

        return customerRepository.save(cust);
    }
}
